package DreadLordGaming.FileExplorerPlus.app;


import com.mrcrayfish.device.api.ApplicationManager;
import com.mrcrayfish.device.api.app.Application;
import com.mrcrayfish.device.api.app.Icons;
import com.mrcrayfish.device.api.app.Layout;
import com.mrcrayfish.device.api.app.component.Button;
import com.mrcrayfish.device.api.app.component.ComboBox;
import com.mrcrayfish.device.api.app.component.ItemList;
import com.mrcrayfish.device.api.app.renderer.ListItemRenderer;
import com.mrcrayfish.device.api.utils.RenderUtil;
import com.mrcrayfish.device.object.AppInfo;
import com.mrcrayfish.device.programs.system.layout.StandardLayout;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.text.TextFormatting;

import java.awt.*;
import java.util.ArrayList;


/**
 * Created by DreadLordGaming on 15/01/2018.
 */
public class ApplicationFileExplorerPlus extends Application {

    public static final int LAYOUT_WIDTH = 255;
    private StandardLayout layoutPictures;
    private StandardLayout layoutMusic;
    private StandardLayout layoutDownloads;
    private StandardLayout layoutDocuments;
    private Button buttonPictures;
    private Button buttonMusic;
    private Button buttonDownloads;
    private Button buttonDocuments;
    private StandardLayout layoutMain;
    protected Application app;

    @Override
    public void init() {

        layoutPictures = new StandardLayout ("Pictures",255, 140, this, layoutMain);
        layoutMusic = new StandardLayout ("Music",255, 140, this, layoutMain);
        layoutDownloads = new StandardLayout ("Downloads",255, 140, this, layoutMain);
        layoutDocuments = new StandardLayout ("Documents",255, 140, this, layoutMain);

        this.layoutMain = new StandardLayout("Computer", 255, 140, this, (Layout) null);
        this.layoutMain.setIcon(Icons.COMPUTER);
        this.setCurrentLayout(layoutMain);

        buttonPictures = new Button(5, 30, 57, 15, "Pictures", Icons.PICTURE);
        buttonPictures.setClickListener((mouseX, mouseY, mouseButton) -> {
            if(mouseButton == 0) {
                this.setCurrentLayout(layoutPictures);
            }

        });
        this.addComponent(buttonPictures);
        this.layoutMain.addComponent(buttonPictures);

        buttonMusic = new Button(5, 50, 57, 15, "Music   ", Icons.MUSIC);
        buttonMusic.setClickListener((mouseX, mouseY, mouseButton) -> {
            if(mouseButton == 0) {
                this.setCurrentLayout(layoutMusic);
            }

        });
        this.addComponent(buttonMusic);
        this.layoutMain.addComponent(buttonMusic);

        buttonDownloads = new Button(5, 70, 57, 15, "Downlo..", Icons.EARTH);
        buttonDownloads.setClickListener((mouseX, mouseY, mouseButton) -> {
            if(mouseButton == 0) {
                this.setCurrentLayout(layoutDownloads);
            }

        });
        this.addComponent(buttonDownloads);
        this.layoutMain.addComponent(buttonDownloads);

        buttonDocuments = new Button(5, 90, 57, 15, "Docume..", Icons.BOOK_CLOSED);
        buttonDocuments.setClickListener((mouseX, mouseY, mouseButton) -> {
            if(mouseButton == 0) {
                this.setCurrentLayout(layoutDocuments);
            }

        });
        this.addComponent(buttonDocuments);
        this.layoutMain.addComponent(buttonDocuments);

        ItemList<AppInfo> itemList = new ItemList<>(80, 35, 255, 5, true);
        itemList.setItems(new ArrayList<>(ApplicationManager.getSystemApplications()));
        layoutMain.addComponent(itemList);
        itemList.setListItemRenderer(new ListItemRenderer<AppInfo>(18) {
            @Override
            public void render(AppInfo appInfo, Gui gui, Minecraft minecraft, int i, int i1, int i2, int i3, boolean b) {
                GlStateManager.color(1.0F, 1.0F, 1.0F);
                RenderUtil.drawApplicationIcon(info, (double)(x + 2), (double)(y + 2));
                RenderUtil.drawStringClipped(info.getName() + TextFormatting.GRAY + " - " + TextFormatting.DARK_GRAY + info.getDescription(),  + 20, + 5, itemList.getWidth() - 255, Color.WHITE.getRGB(), false);
            }
        });

    }

    @Override
    public void load(NBTTagCompound nbtTagCompound) {

    }

    @Override
    public void save(NBTTagCompound nbtTagCompound) {

    }

    public ApplicationFileExplorerPlus() {
        this.setDefaultWidth(255);
        this.setDefaultHeight(140);
    }
}