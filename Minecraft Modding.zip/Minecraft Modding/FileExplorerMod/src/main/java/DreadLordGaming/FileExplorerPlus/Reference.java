package DreadLordGaming.FileExplorerPlus;

/**
 * Created by DreadLordGaming on 15/01/2018.
 */
public class Reference {

    public static final String MODID = "fileeexp";
    public static final String NAME = "File Explorer Plus";
    public static final String VERSION = "1.0";

    public static final String DEPENDENCIES = "required-after:cdm@[" + com.mrcrayfish.device.Reference.VERSION + ",)";
    public static final String WORKING_MC_VERSION = "[1.12.2]";
    public static final String CLIENT_PROXY = "DreadLordGaming.FileExplorerPlus.proxy.ClientProxy";
    public static final String COMMON_PROXY = "DreadLordGaming.FileExplorerPlus.proxy.CommonProxy";
}
