package DreadLordGaming.FileExplorerPlus.proxy;

/**
 * Created by starwars on 15/01/2018.
 */
public class CommonProxy {
    public void init() {
    }

    public void preinit() {
    }
}
