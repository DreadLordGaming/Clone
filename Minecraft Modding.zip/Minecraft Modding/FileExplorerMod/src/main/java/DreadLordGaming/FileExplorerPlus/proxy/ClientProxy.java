package DreadLordGaming.FileExplorerPlus.proxy;

import com.sun.org.apache.xml.internal.security.Init;

/**
 * Created by DreadLordGaming on 15/01/2018.
 */
public class ClientProxy extends CommonProxy {

    @Override
    public void init() {
        super.init();
    }


}
