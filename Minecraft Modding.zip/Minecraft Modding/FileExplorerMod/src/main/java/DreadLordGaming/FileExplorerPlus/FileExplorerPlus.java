package DreadLordGaming.FileExplorerPlus;

import DreadLordGaming.FileExplorerPlus.app.ApplicationFileExplorerPlus;
import DreadLordGaming.FileExplorerPlus.proxy.CommonProxy;
import com.mrcrayfish.device.api.ApplicationManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = Reference.MODID, name = Reference.NAME, version = Reference.VERSION, dependencies = Reference.DEPENDENCIES, acceptedMinecraftVersions = Reference.WORKING_MC_VERSION)
public class FileExplorerPlus {

    @Mod.Instance
    public static FileExplorerPlus instance;

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        proxy.init();
        ApplicationManager.registerApplication(new ResourceLocation(Reference.MODID, "fileeexp"),
                ApplicationFileExplorerPlus.class);
    }

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        proxy.preinit();

    }

    @SidedProxy(clientSide = Reference.CLIENT_PROXY, serverSide = Reference.COMMON_PROXY)
    public static CommonProxy proxy;
}